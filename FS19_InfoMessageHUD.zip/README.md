# (EN) FS19 Info Message HUD
There are those info messages within the help (F1) menu. Those show for example when you're within a trigger and can perform a given action. But also the messages which tell you that you've
to fill an implement first.

This mod shows these messages in the upper left corner when you're hiding the help (F1) menu, so that you never miss an action, and don't have to show the help menu all the time.

Normal messages are shown in white, if the message is related to an action it will be shown in yellow.



# (DE) FS19 Info Nachrichten HUD
Man kennt ja diese Infomeldungen die im Hilfemenü (F1) angezeigt werden. Diese zeigen z.B. an das man sich in einem Trigger befindet und eine Aktion ausführen kann, aber auch das ein
Anbaugerät aufgefüllt werden muss.

Damit man nicht immer mit aufgeklappten Hilfe/F1 Menü herumlaufen muss, zeigt dieser Mod eben diese Meldungen immer links oben an. Natürlich Kontextbezogen, und eben nur wenn es
auch solche Meldungen gibt.

Dabei werden Standardmeldugnen in Weiß, und mögliche Aktionen in Gelb angezeigt.